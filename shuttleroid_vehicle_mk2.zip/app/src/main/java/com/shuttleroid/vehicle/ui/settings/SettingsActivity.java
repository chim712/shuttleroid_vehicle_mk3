package com.shuttleroid.vehicle.ui.settings;

public class SettingsActivity {
}
