package com.shuttleroid.vehicle.data.dto;

// Server -> Application
public class CourseDto {
    public long routeID;
    public String departureTime;
}
