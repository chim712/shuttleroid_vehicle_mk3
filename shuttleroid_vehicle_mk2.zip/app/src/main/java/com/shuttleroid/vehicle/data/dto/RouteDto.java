package com.shuttleroid.vehicle.data.dto;

import java.util.List;

public class RouteDto {
    public Long routeID;
    public String routeName;
    public int spendTime;
    public List<Long> stopIds;
}
