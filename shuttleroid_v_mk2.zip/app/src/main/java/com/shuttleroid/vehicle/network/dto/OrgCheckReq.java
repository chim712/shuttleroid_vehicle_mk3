package com.shuttleroid.vehicle.network.dto;

public class OrgCheckReq {
    public Long orgID;
}
