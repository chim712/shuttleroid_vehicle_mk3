package com.shuttleroid.vehicle.network.dto;

public class OrgCheckRes {
    public String orgName;
}
