// app/src/main/java/com/shuttleroid/vehicle/data/database/AppDatabase.java
package com.shuttleroid.vehicle.data.database;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.shuttleroid.vehicle.data.dao.BusStopDao;
import com.shuttleroid.vehicle.data.entity.BusStop;

@Database(
        entities = { BusStop.class /*, Route, RouteStopCrossRef 등*/ },
        version = 1,
        exportSchema = false
)
public abstract class AppDatabase extends RoomDatabase {
    private static volatile AppDatabase INSTANCE;
    public abstract BusStopDao busStopDao();

    public static AppDatabase get(Context ctx){
        if (INSTANCE == null) {
            synchronized (AppDatabase.class) {
                if (INSTANCE == null) {
                    INSTANCE = Room.databaseBuilder(ctx.getApplicationContext(),
                                    AppDatabase.class, "vehicle.db")
                            .fallbackToDestructiveMigration() // 개발 단계
                            .build();
                }
            }
        }
        return INSTANCE;
    }
}
