// app/src/main/java/com/shuttleroid/vehicle/data/repo/IntegratedRepository.java
package com.shuttleroid.vehicle.data.repo;

import android.content.Context;
import androidx.annotation.WorkerThread;
import com.shuttleroid.vehicle.data.database.AppDatabase;
import com.shuttleroid.vehicle.data.entity.BusStop;
import com.shuttleroid.vehicle.data.mapper.UpdateSnapshotMapper;
import com.shuttleroid.vehicle.network.dto.UpdateSnapshot;
import java.util.List;

public class IntegratedRepository {
    private final AppDatabase db;

    public IntegratedRepository(Context ctx){
        this.db = AppDatabase.get(ctx);
    }

    /** /update 스냅샷을 Room에 반영 */
    @WorkerThread
    public void replaceAll(UpdateSnapshot snap){
        List<BusStop> stops = UpdateSnapshotMapper.toBusStops(snap);
        db.runInTransaction(() -> {
            db.busStopDao().clear();
            if (!stops.isEmpty()) db.busStopDao().upsertAll(stops);
            // Route/Ref 테이블도 있으면 여기에 같이 갈아끼우기
        });
    }

    public int busStopCount(){
        return db.busStopDao().count();
    }
}
