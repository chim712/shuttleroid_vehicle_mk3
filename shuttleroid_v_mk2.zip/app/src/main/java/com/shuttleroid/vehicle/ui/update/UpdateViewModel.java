// app/src/main/java/com/shuttleroid/vehicle/ui/update/UpdateViewModel.java
package com.shuttleroid.vehicle.ui.update;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;

import com.shuttleroid.vehicle.app.SessionStore;
import com.shuttleroid.vehicle.data.repo.IntegratedRepository;
import com.shuttleroid.vehicle.network.api.SyncService;
import com.shuttleroid.vehicle.network.client.RetrofitProvider;
import com.shuttleroid.vehicle.network.dto.UpdateSnapshot;
import com.shuttleroid.vehicle.network.dto.ScheduleItem;
import com.shuttleroid.vehicle.util.Toasts;

import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdateViewModel extends AndroidViewModel {

    private final SyncService api;
    private final IntegratedRepository repo;
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    public final MutableLiveData<Boolean> updateDone = new MutableLiveData<>(false);
    public final MutableLiveData<List<ScheduleItem>> scheduleLive = new MutableLiveData<>();

    public UpdateViewModel(@NonNull Application app) {
        super(app);
        api = RetrofitProvider.get().create(SyncService.class);
        repo = new IntegratedRepository(app);
    }

    public void doUpdate(long dataVer){
        SessionStore s = SessionStore.getInstance();
        Long org = s.getOrgId();
        if (org == null){
            Toasts.throttled(getApplication(), "orgID 없음");
            return;
        }
        api.update(org, dataVer).enqueue(new Callback<UpdateSnapshot>() {
            @Override public void onResponse(Call<UpdateSnapshot> call, Response<UpdateSnapshot> resp) {
                if (resp.code()==204){
                    Toasts.throttled(getApplication(),"최신버전입니다");
                    updateDone.postValue(true);
                    return;
                }
                if (resp.isSuccessful() && resp.body()!=null){
                    UpdateSnapshot snap = resp.body();
                    io.execute(() -> {
                        repo.replaceAll(snap); // ★ 실제 저장
                        int cnt = repo.busStopCount();
                        updateDone.postValue(true);
                        // 개발용 확인 토스트
                        Toasts.throttled(getApplication(), "BusStop 저장: " + cnt + "건");
                    });
                } else {
                    Toasts.throttled(getApplication(),"서버 연결 불가");
                    updateDone.postValue(false);
                }
            }
            @Override public void onFailure(Call<UpdateSnapshot> call, Throwable t) {
                Toasts.throttled(getApplication(),"서버 연결 불가");
                updateDone.postValue(false);
            }
        });
    }

    // loadTodaySchedule()는 그대로
}
