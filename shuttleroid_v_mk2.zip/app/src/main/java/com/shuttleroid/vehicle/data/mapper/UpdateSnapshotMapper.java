// app/src/main/java/com/shuttleroid/vehicle/data/mapper/UpdateSnapshotMapper.java
package com.shuttleroid.vehicle.data.mapper;

import com.shuttleroid.vehicle.data.entity.BusStop;
import com.shuttleroid.vehicle.network.dto.UpdateSnapshot;
import java.util.ArrayList;
import java.util.List;

public final class UpdateSnapshotMapper {
    private UpdateSnapshotMapper(){}

    public static List<BusStop> toBusStops(UpdateSnapshot s){
        List<BusStop> out = new ArrayList<>();
        if (s == null || s.stopList == null) return out;
        for (UpdateSnapshot.BusStopDto d : s.stopList){
            BusStop b = new BusStop();
            b.stopID = d.stopID != null ? d.stopID : 0L;
            b.stopName = d.stopName != null ? d.stopName : "";
            b.latitude = d.latitude;
            b.longitude = d.longitude;
            b.approach = parseIntOrZero(d.approach);
            b.arrival  = parseIntOrZero(d.arrival);
            b.leave    = parseIntOrZero(d.leave);
            out.add(b);
        }
        return out;
    }

    private static int parseIntOrZero(String s){
        try { return s == null ? 0 : Integer.parseInt(s.trim()); }
        catch (Exception e){ return 0; }
    }
}
