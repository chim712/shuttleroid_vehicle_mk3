package com.shuttleroid.vehicle.network.dto;

public class LoginReq {
    public Long orgID;
    public Long driverID;
    public String password;
}
