package com.shuttleroid.vehicle.network.dto;

public class LogoutReq {
    public Long orgID;
    public Long driverID;
}
