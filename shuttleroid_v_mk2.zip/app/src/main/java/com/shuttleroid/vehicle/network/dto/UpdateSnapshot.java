// app/src/main/java/com/shuttleroid/vehicle/network/dto/UpdateSnapshot.java
package com.shuttleroid.vehicle.network.dto;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class UpdateSnapshot {
    @SerializedName("organizationId") public Long organizationId;  // 선택
    @SerializedName("updateVersion")  public Long updateVersion;   // = dataVer
    @SerializedName("stopList")       public List<BusStopDto> stopList; // ★ 서버 키와 동일

    public static class BusStopDto {
        @SerializedName("stopID")    public Long stopID;
        @SerializedName("stopName")  public String stopName;
        @SerializedName("latitude")  public double latitude;
        @SerializedName("longitude") public double longitude;
        @SerializedName("approach")  public String approach; // "500" 같은 문자열일 가능성
        @SerializedName("arrival")   public String arrival;
        @SerializedName("leave")     public String leave;
    }
}
