package com.shuttleroid.vehicle.network.dto;

public class LoginRes {
    public String vehicleID;  // 예: "경기78아8639"
}
